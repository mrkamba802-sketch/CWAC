# CWanticheat

CWanticheat is a Minecraft server anticheat fork based on the LightningGrim/Grim codebase.
The Bukkit/Paper plugin metadata is published as **CWanticheat** by **ClacyWorld**.

## Build

Requirements: JDK 25 for the configured Paper 26.3 development run target; the Java source
modules compile with the Gradle toolchain configured by the project.

```bash
./gradlew :bukkit:shadowJar
```

The Bukkit plugin JAR is written under `bukkit/build/libs/`.

## Commands and permissions

The root command is `/cwanticheat` (short alias `/cwac`). Permissions use the
`cwanticheat.*` namespace.

## Punishments

Default punishment groups are organized by check family. The `Timer` group includes
`Timer`, `TimerLimit`, `TickTimer`, `NegativeTimer`, and `VehicleTimer`.

## License and source

This project retains the upstream GPL-3.0 license and applicable notices. Because this
fork is based on GPL-licensed code, distribute modified binaries together with the
corresponding source under the terms of that license.
