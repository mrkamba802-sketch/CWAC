# Что изменено в CWanticheat

## Брендинг и команды

- Имя Bukkit/Paper-плагина задаётся как `CWanticheat`, автор — `ClacyWorld`. Файл `plugin.yml` генерируется Gradle-плагином из `bukkit/build.gradle.kts`, поэтому отдельного исходного `plugin.yml` в проекте нет.
- Основная команда: `/cwanticheat`; короткий алиас: `/cwac`; команда загрузки лога: `/cwlog`.
- Командные и игровые permission-ноды переведены в пространство имён `cwanticheat.*`, включая динамические `exempt`, `nosetback` и `nomodifypacket` для отдельных проверок.
- PlaceholderAPI expansion использует идентификатор `cwanticheat`.
- Префикс, формат обычных/прокси-алертов и Discord embed оформлены зелёными оттенками. Обновлены все поставляемые локализации.

## Punishments

Все 137 проверок, объявленных через `@CheckData`, сопоставлены ровно с одной группой в `Punishments` во всех локалях. Всего создано 28 групп:

`Simulation`, `GroundSpoof`, `Timer`, `BadPackets`, `PacketOrder`, `Crash`, `Sprint`, `NoSlow`, `Chat`, `Elytra`, `MultiActions`, `Knockback`, `Explosion`, `Post`, `Inventory`, `Reach`, `Hitboxes`, `WallHit`, `EntityPierce`, `Vehicle`, `Baritone`, `Break`, `Place`, `MultiInteract`, `Aim`, `Exploit`, `Phase`, `TransactionOrder`.

Группа `Timer` покрывает `Timer`, `TimerLimit`, `TickTimer`, `NegativeTimer` и `VehicleTimer`. Группа `GroundSpoof` также покрывает `NoFall`. Для остальных семейств используются отдельные группы.

В исходниках присутствует `FlightA.java` без `@CheckData`; класс нигде не регистрируется/не создаётся, поэтому он не является активной проверкой и не может быть сопоставлен с `Punishments` без отдельного решения о его включении.

## Совместимость и сборка

Внутренние Java-пакеты `ac.grim.grimac`, классы API и стабильные внутренние ключи `grim.*` сохранены: это implementation/storage identifiers исходной кодовой базы, их массовое переименование может нарушить ссылки и совместимость с данными. Публичное имя плагина, команды, permissions и placeholder-префикс уже переименованы.

YAML-конфиги проверены парсером: ошибок разбора нет. Проверка покрытия `@CheckData` также прошла — пропусков и повторных назначений нет.

JAR в этом архиве не приложен: в окружении подготовки Gradle Wrapper не смог скачать Gradle 9.8.2 (`services.gradle.org` недоступен), а установленный JDK 21 ниже настроенной для Paper 26.3 версии Java 25. Для сборки на машине с доступом к Gradle distribution и JDK 25 выполните:

```bash
./gradlew :bukkit:shadowJar
```

Готовый Bukkit/Paper JAR появится в `bukkit/build/libs/`.
