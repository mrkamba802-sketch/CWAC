import net.minecrell.pluginyml.bukkit.BukkitPluginDescription.Permission
import versioning.BuildConfig
import java.util.zip.ZipFile

plugins {
    `maven-publish`
    grim.`base-conventions`
    grim.`shadow-conventions`
    id("de.eldoria.plugin-yml.bukkit") version "0.8.0"
    id("xyz.jpenilla.run-paper") version "3.0.0-beta.1"
}

repositories {
    val localOverride = if (BuildConfig.mavenLocalOverride) mavenLocal() else null

    // Exclusive Repositories (One HTTP request per dep)
    exclusive("https://repo.papermc.io/repository/maven-public/", { name = "papermc" }) {
        includeGroup("io.papermc.paper")
        includeGroup("net.md-5")
    }

    exclusive("https://libraries.minecraft.net", { mavenContent { releasesOnly() } }) {
        includeModule("com.mojang", "brigadier")
    }

    exclusive("https://repo.extendedclip.com/content/repositories/placeholderapi/") {
        includeGroup("me.clip")
    }

    val grimPublicReleases = maven("https://maven.grim.ac/public/releases") {
        mavenContent { releasesOnly() }
    }
    val grimPublicSnapshots = maven("https://maven.grim.ac/public/snapshots") {
        mavenContent { snapshotsOnly() }
    }
    val grimLegacySnapshots = maven("https://repo.grim.ac/snapshots")
    exclusiveContent {
        forRepositories(*listOfNotNull(localOverride, grimPublicReleases, grimPublicSnapshots, grimLegacySnapshots).toTypedArray())
        filter {
            includeGroup("ac.grim.grimac")
            includeGroup("com.github.retrooper")
        }
    }

    exclusive("https://nexus.scarsz.me/content/repositories/releases", { mavenContent { releasesOnly() } }) {
        includeGroup("github.scarsz")
    }

    mavenCentral()
}

val configuredLiteSharedProviderJar = providers.gradleProperty("grim.liteSharedProviderJar")
    .orElse(providers.gradleProperty("liteSharedProviderJar"))

// PE's published Spigot artifact is thin. Its runtime jar bundles these modules,
// with text serializers relocated into PE's own namespace.
val liteSharedLibraries by configurations.creating {
    isCanBeConsumed = false
    isTransitive = false
}
val liteCatalog = extensions.getByType<VersionCatalogsExtension>().named("libs")
if (!BuildConfig.shadePE) {
    val adventureVersion = liteCatalog.findVersion("adventure").get().requiredVersion
    val examinationVersion = liteCatalog.findVersion("examination").get().requiredVersion
    for (module in listOf("adventure-api", "adventure-key", "adventure-nbt")) {
        dependencies.add(liteSharedLibraries.name, "net.kyori:$module:$adventureVersion")
    }
    for (module in listOf("examination-api", "examination-string")) {
        dependencies.add(liteSharedLibraries.name, "net.kyori:$module:$examinationVersion")
    }
}

val liteSharedPrefixes = listOf(
    "net/kyori/adventure/",
    "net/kyori/examination/",
    "net/kyori/option/",
)

var cachedLiteSharedProviderClassEntries: Set<String>? = null
var cachedLiteSharedProviderFiles: List<File>? = null

fun liteSharedProviderFiles(): List<File> {
    cachedLiteSharedProviderFiles?.let { return it }

    val configured = configuredLiteSharedProviderJar.orNull
        ?.split(File.pathSeparator)
        ?.filter { it.isNotBlank() }
        ?.map { file(it) }
        ?.takeIf { it.isNotEmpty() }

    val files = configured ?: liteSharedLibraries.resolve().toList()

    cachedLiteSharedProviderFiles = files
    return files
}

fun liteSharedProviderClassEntries(): Set<String> {
    cachedLiteSharedProviderClassEntries?.let { return it }

    val entries = liteSharedProviderFiles().flatMap { jar ->
        ZipFile(jar).use { zip ->
            zip.entries().asSequence()
                .map { it.name }
                .filter { name ->
                    name.endsWith(".class") && liteSharedPrefixes.any(name::startsWith) &&
                        !name.startsWith("net/kyori/adventure/text/serializer/")
                }
                .toList()
        }
    }.toSet()

    cachedLiteSharedProviderClassEntries = entries
    return entries
}


dependencies {
    compileOnly(libs.paper.api)
    compileOnly(libs.placeholderapi)
    compileOnly(libs.luckperms)

    if (BuildConfig.shadePE) {
        implementation(libs.packetevents.spigot)
    } else {
        compileOnly(libs.packetevents.spigot)
    }
    implementation(libs.cloud.paper)
    implementation(libs.adventure.platform.bukkit)
    implementation(libs.grim.bukkit.internal)

    implementation(project(":common"))
    shadow(project(":common"))
}

bukkit {
    name = "CWanticheat"
    author = "ClacyWorld"
    main = "ac.grim.grimac.platform.bukkit.GrimACBukkitLoaderPlugin"
    apiVersion = "1.13"
    foliaSupported = true

    if (!BuildConfig.shadePE) {
        depend = listOf("packetevents")
    }

    softDepend = listOf(
        "ProtocolLib",
        "ProtocolSupport",
        "Essentials",
        "ViaVersion",
        "ViaBackwards",
        "ViaRewind",
        "Geyser-Spigot",
        "floodgate",
        "FastLogin",
        "PlaceholderAPI",
        "LuckPerms",
        // Driver holder mods — softdepend so each backend's driver class
        // resolves through the linked classloader.
        "sqlite-jdbc",
        "mysql-jdbc",
        "postgresql-jdbc",
        "mongodb-driver",
        "jedis",
    )

    permissions {
        register("cwanticheat.alerts") {
            description = "Receive alerts for violations"
            default = Permission.Default.OP
        }

        register("cwanticheat.alerts.enable-on-join") {
            description = "Enable alerts on join"
            default = Permission.Default.OP
        }

        register("cwanticheat.alerts.enable-on-join.silent") {
            description = "Enable alerts on join without a toggle message"
            default = Permission.Default.FALSE
        }

        register("cwanticheat.performance") {
            description = "Check performance metrics"
            default = Permission.Default.OP
        }

        register("cwanticheat.profile") {
            description = "Check user profile"
            default = Permission.Default.OP
        }

        register("cwanticheat.brand") {
            description = "Show client brands on join"
            default = Permission.Default.OP
        }

        register("cwanticheat.brand.enable-on-join") {
            description = "Enable showing client brands on join"
            default = Permission.Default.OP
        }

        register("cwanticheat.brand.enable-on-join.silent") {
            description = "Enable client brands on join without a toggle message"
            default = Permission.Default.FALSE
        }

        register("cwanticheat.sendalert") {
            description = "Send cheater alert"
            default = Permission.Default.OP
        }

        register("cwanticheat.testwebhook") {
            description = "Test the configured Discord webhook"
            default = Permission.Default.OP
        }

        register("cwanticheat.nosetback") {
            description = "Disable setback"
            default = Permission.Default.FALSE
        }

        register("cwanticheat.nomodifypacket") {
            description = "Disable modifying packets"
            default = Permission.Default.FALSE
        }

        register("cwanticheat.disabled") {
            description = "Disable CWanticheat checks while keeping player state tracked"
            default = Permission.Default.FALSE
        }

        register("cwanticheat.exempt") {
            description = "Exempt from all checks"
            default = Permission.Default.FALSE
        }

        register("cwanticheat.verbose") {
            description = "Receive verbose alerts for violations"
            default = Permission.Default.OP
        }

        register("cwanticheat.verbose.enable-on-join") {
            description = "Enable verbose alerts on join"
            default = Permission.Default.FALSE
        }

        register("cwanticheat.verbose.enable-on-join.silent") {
            description = "Enable verbose alerts on join without a toggle message"
            default = Permission.Default.FALSE
        }

        register("cwanticheat.list") {
            description = "Show lists of specific data"
            default = Permission.Default.FALSE
        }

        register("cwanticheat.help") {
            description = "View CWanticheat command help"
            default = Permission.Default.OP
        }

        register("cwanticheat.reload") {
            description = "Reload CWanticheat configuration"
            default = Permission.Default.OP
        }

        register("cwanticheat.spectate") {
            description = "Spectate players"
            default = Permission.Default.OP
        }

        register("cwanticheat.spectate.stophere") {
            description = "Allow stopping spectate at the current location"
            default = Permission.Default.FALSE
        }

        register("cwanticheat.version") {
            description = "View CWanticheat version information"
            default = Permission.Default.OP
        }

        register("cwanticheat.log") {
            description = "Upload a debug log"
            default = Permission.Default.OP
        }

        register("cwanticheat.debug") {
            description = "View player prediction debug output"
            default = Permission.Default.OP
        }

        register("cwanticheat.consoledebug") {
            description = "View prediction debug output in console"
            default = Permission.Default.OP
        }

        register("cwanticheat.hitboxdebug") {
            description = "View hitbox debug information"
            default = Permission.Default.OP
        }

        register("cwanticheat.dump") {
            description = "Generate a CWanticheat debug dump"
            default = Permission.Default.OP
        }

        register("cwanticheat.history") {
            description = "View player violation history"
            default = Permission.Default.OP
        }

        register("cwanticheat.history.repair") {
            description = "Repair violation history data"
            default = Permission.Default.OP
        }

        register("cwanticheat.history.copy") {
            description = "Copy violation history between storage backends"
            default = Permission.Default.OP
        }

        register("cwanticheat.history.migrate") {
            description = "Migrate legacy violation history"
            default = Permission.Default.OP
        }

        register("cwanticheat.spectator") {
            description = "Hide spectator players from other players"
            default = Permission.Default.FALSE
        }
    }
}

publishing.publications.create<MavenPublication>("maven") {
    artifact(tasks["shadowJar"])
}

tasks {
    // 1.8.8 - 1.16.5   = Java 8
    // 1.17             = Java 16
    // 1.18 - 1.20.4    = Java 17
    // 1.20.5 - 1.21.11 = Java 21
    // 26.1+            = Java 25
    val version = "26.3"
    val javaVersion = JavaLanguageVersion.of(25)

    val jvmArgsExternal = listOf(
        "-Dcom.mojang.eula.agree=true",
        "-Dpaper.explicit-flush=true",
        "-DPaper.IgnoreJavaVersion=true"
    )

    runServer {
        minecraftVersion(version)
        runDirectory = projectDir.resolve("run/$version")

        val javaToolchains = project.extensions.getByType<JavaToolchainService>()
        javaLauncher = javaToolchains.launcherFor {
            vendor = JvmVendorSpec.JETBRAINS
            languageVersion = javaVersion
        }

        jvmArgs = jvmArgsExternal
    }

    shadowJar {
        exclude("META-INF/services/javax.annotation.processing.Processor")

        if (!BuildConfig.shadePE) {
            inputs.files(provider { liteSharedProviderFiles() }).withPropertyName("liteSharedProviders")
            exclude {
                val path = it.path
                path.endsWith(".class") && path in liteSharedProviderClassEntries()
            }

            doFirst {
                logger.lifecycle(
                    "Excluding ${liteSharedProviderClassEntries().size} shared class entries supplied by PacketEvents: " +
                        liteSharedProviderFiles().joinToString { it.name }
                )
            }
        }

        manifest {
            attributes["paperweight-mappings-namespace"] = "mojang"
        }
    }
}
